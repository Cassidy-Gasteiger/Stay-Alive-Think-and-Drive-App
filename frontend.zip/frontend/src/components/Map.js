import React from 'react'

function Map() {
  const mapStyle = {
    backgroundColor: 'green',
    height: '100vh',
    width: '100%',
  };


  return (
    <div style={mapStyle}>Map123</div>
  )
}

export default Map



// return (
//   <div className='h-20 bg-green-400'>Map</div>
// )
// }