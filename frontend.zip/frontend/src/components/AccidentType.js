import React from 'react'

function AccidentType() {
  return (
    <div>AccidentType</div>
  )
}

export default AccidentType